//TODO Game

#ifndef Game_h
#define Game_h

#include "Constant.h"
#include "Block.h"
#include "MovingObj.h"
#include "NextObj.h"
#include "RemainObj.h"

class Game
{
public:
	Game(int);
	~Game();

	//Following methods are used to change states
	//TODO Moving Horizontally false for left true for right
	void MovingHorizontal(bool direction);

	//TODO Moving Vertically only this can change game state
	void MovingVertical(bool direction = false);

	//TODO Rotate
	void MovingRotate(bool direction = true);
	
	//TODO Start and Restart
	void GameInit();

	//TODO stop set by player
	void GameStop();

	//TODO continue set by player
	void GameContinue();

	//Following methods are used to get states
	//TODO get blocks' states moving and remain
	std::vector<Block> GetBlocksState() const;

	//TODD get blocks next
	std::vector<Block> GetNextBlock() const;

	//TODO get scores
	int GetScores() const;

	//TODO whether it is the  game states
	bool IsState(int state) const;

private:

	//TODO whether it is finished (before next combination) and change 
	// this method is called by 
	bool isFinished();

	//Following methods are about states
	//TODO initialize
	void InitStates();

	//TODO set states
	void SetState(int state);

	//Following is the members
	//TODO states and scores
	int				p_mState;
	int				p_mScore;

	//TODO 3 major objects
	MovingObj		p_movingObj;
	NextObj			p_nextObj;
	RemainObj		p_remainObj;
};


#endif // !Game_h


// 	//TODO whether the states is legal and change the state
// 	bool StateisLegal(const std::vector<Block> &ths);


// 	//TODO the next combination
// 	void NextCombination();


// 	//TODO should reproduce next combination
// 	bool NextCombinationNeeded();



// 	//Following methods are about blocks
// 	//TODO copy the blocks
// 	void CpyBlocks(std::vector<Block> &from, std::vector<Block> &to);
// 
// 	//TODO add stopped blocks
// 	void AddBlocks();
// 
// 	//TODO move horizontally
// 	void HaStep(std::vector<Block> &ths, bool direciton) const;
// 
// 	//TODO move vertically and decide whether next combination  should come
// 	void VaStep(std::vector<Block> &ths, bool direction) const;
// 
// 	//TODO rotate
// 	void RaStep(std::vector<Block> &ths, bool direction) const;









// 	//TODO flag should next renew
// 	int p_mShouldBeNext;



	// //TODO blocks warehouse
	// std::vector<Block> p_mBlocks;
	// std::vector<Block> p_mMovingBlocks;
	// std::vector<Block> p_mNextBlocks;

	// //TODO the iterator help
	// std::vector<Block>::iterator it_ths;
	// std::vector<Block>::iterator it_rhs;
	// std::vector<Block>::iterator it_from;
	// std::vector<Block>::iterator it_to;