
#include "NextObj.h"

bool NextObj::isFirstCalled = 1;

NextObj::NextObj()
{
	if(isFirstCalled)
	{
		srand(time(NULL));
		isFirstCalled = 0;
	}
	initNext();
}

NextObj::~NextObj(){}

std::vector<Block> NextObj::getBlocks() const
{
	std::vector<Block> tmpNext(p_mblocks, p_mblocks + 4);
	return tmpNext;
}

int NextObj::getChoice() const
{
	return p_mChoice;
}

void NextObj::initNext()
{
	int choice = rand() % 7;
	NextBlocks(choice);
	NextChoice(choice);
}

void NextObj::NextChoice(int choice)
{
	p_mChoice = choice;
}

void NextObj::NextBlocks(int choice)
{
	if (choice == 0)
	{
		p_mblocks[0].reSet(0, 0, rand() % 2 + 1);
		p_mblocks[1].reSet(0, 1, rand() % 2 + 1);
		p_mblocks[2].reSet(1, 0, rand() % 2 + 1);
		p_mblocks[3].reSet(1, 1, rand() % 2 + 1);
		return ;
	}

	if (choice == 1)
	{
		p_mblocks[0].reSet(1, 0, rand() % 2 + 1);
		p_mblocks[1].reSet(1, 1, rand() % 2 + 1);
		p_mblocks[2].reSet(1, 2, rand() % 2 + 1);
		p_mblocks[3].reSet(1, 3, rand() % 2 + 1);
		return ;
	}

	if (choice == 2)
	{
		p_mblocks[0].reSet(0, 0, rand() % 2 + 1);
		p_mblocks[1].reSet(1, 0, rand() % 2 + 1);
		p_mblocks[2].reSet(1, 1, rand() % 2 + 1);
		p_mblocks[3].reSet(1, 2, rand() % 2 + 1);
		return ;
	}

	if (choice == 3)
	{
		p_mblocks[0].reSet(0, 2, rand() % 2 + 1);
		p_mblocks[1].reSet(1, 0, rand() % 2 + 1);
		p_mblocks[2].reSet(1, 1, rand() % 2 + 1);
		p_mblocks[3].reSet(1, 2, rand() % 2 + 1);
		return ;
	}

	if (choice == 4)
	{
		p_mblocks[0].reSet(0, 1, rand() % 2 + 1);
		p_mblocks[1].reSet(0, 2, rand() % 2 + 1);
		p_mblocks[2].reSet(1, 0, rand() % 2 + 1);
		p_mblocks[3].reSet(1, 1, rand() % 2 + 1);
		return ;
	}

	if (choice == 5)
	{
		p_mblocks[0].reSet(0, 0, rand() % 2 + 1);
		p_mblocks[1].reSet(0, 1, rand() % 2 + 1);
		p_mblocks[2].reSet(1, 1, rand() % 2 + 1);
		p_mblocks[3].reSet(1, 2, rand() % 2 + 1);
		return ;
	}

	if (choice == 6)
	{
		p_mblocks[0].reSet(0, 1, rand() % 2 + 1);
		p_mblocks[1].reSet(1, 0, rand() % 2 + 1);
		p_mblocks[2].reSet(1, 1, rand() % 2 + 1);
		p_mblocks[3].reSet(1, 2, rand() % 2 + 1);
		return ;
	}
}



// 	// a square
// 	if (choice == 0)
// 	{
// 		p_mSize = 2;		return;
// 	}
// 	// a line
// 	if (choice == 1)
// 	{
// 		p_mSize = 4;		return;
// 	}
// 	p_mSize = 3;