
#include "Block.h"
Block::~Block(){}

Block::Block(int posi /* = 0 */, int posj /* = 0 */, int num /* = 0 */):
	p_mPosi(posi), p_mPosj(posj), p_mNum(num)
{
	p_mPos[0] = posi;
	p_mPos[1] = posj;
}

Block::Block(const Block &rhs)
{
	p_mPosi = rhs.p_mPosi;
	p_mPosj = rhs.p_mPosj;
	p_mNum  = rhs.p_mNum;
	p_mPos[0] = rhs.p_mPos[0];
	p_mPos[1] = rhs.p_mPos[1];
}

Block& Block::operator=(const Block &rhs)
{
	p_mPosi = rhs.p_mPosi;
	p_mPosj = rhs.p_mPosj;
	p_mNum  = rhs.p_mNum;
	p_mPos[0] = rhs.p_mPos[0];
	p_mPos[1] = rhs.p_mPos[1];

	return *this;
}

void Block::reSet(int posi /* = 0 */, int posj /* = 0 */, int num /* = 0 */)
{
	p_mPosi = posi;
	p_mPosj = posj;
	p_mNum  = num;
	
	p_mPos[0] = posi;
	p_mPos[1] = posj;
}

int Block::getNum()const
{
	return p_mNum;
}

const int* Block::getPos() const
{
	return p_mPos;
}

int Block::getPosi() const
{
	return p_mPosi;
}

int Block::getPosj() const
{
	return p_mPosj;
}