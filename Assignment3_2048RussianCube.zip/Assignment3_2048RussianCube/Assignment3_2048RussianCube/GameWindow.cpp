
#include "GameWindow.h"

Game GameWindow::game=0;

void GameWindow::Init(int argc, char *argv[])
{	
	//TODO init and mode
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);

	//TODO window size
	glutInitWindowSize(Constant::WindowWidth, Constant::WindowHeight);
	glutInitWindowPosition(Constant::WindowPosX, Constant::WindowPosY);
	glutCreateWindow(Constant::Title);
	
	//TODO Background
	glClearColor(1.0f,1.0f,1.0f,1.0f);
	glShadeModel(GL_FLAT);

	//TODO display functions
	glutReshapeFunc(ReshapeFunc);
	glutDisplayFunc(DisplayFunc);

	//TODO timer functions
	glutTimerFunc(Constant::DelayTime, TimeFunc, game.IsState(Constant::GameReady));

	//TODO keyboard functions
	glutKeyboardFunc(KeyboardFunc);
}

void GameWindow::Start()
{
	glutMainLoop();
}

void GameWindow::ReshapeFunc(GLsizei w, GLsizei h)
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);

	GLfloat factor = (GLfloat)w/(GLfloat)h;
	if (w < h) 
		gluOrtho2D (-1.0f, 1.0f, -1.0f / factor, 1.0f / factor);
	else 
		gluOrtho2D (-1.0f * factor, 1.0f *factor, -1.0f, 1.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void GameWindow::DisplayFunc()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


	DisplayBackground();
	DisplayScore(game.GetScores());
	DisplayAction(game.GetBlocksState());


	glutSwapBuffers();
	glFlush();
}

void GameWindow::KeyboardFunc(unsigned char key, int x,int y)
{
	switch(key)
	{
	case 'W':case 'w':
		game.MovingRotate();					break;
	case 'A':case 'a':
		game.MovingHorizontal(false);			break;
	case 'D':case 'd':
		game.MovingHorizontal(true);			break;
	case 'S':case 's':
		game.MovingVertical();					break;
	case 'P':case 'p':
		game.GameStop();						break;
	case 'C':case 'c':
		game.GameContinue();					break;
	case 'R':case 'r':
		game.GameInit();						break;
	}
	Update();
}

void GameWindow::TimeFunc(int value)
{
	if (value == 1)
	{
		game.MovingVertical();
		Update();
		glutTimerFunc(Constant::DelayTime, TimeFunc, game.IsState(Constant::GameReady));
	}
	else
	{
		glutTimerFunc(Constant::DelayTime, TimeFunc, game.IsState(Constant::GameReady));
	}
}

void GameWindow::DisplayBackground()
{
	glColor3fv(Constant::GameColor[0]);
	for (int i = 0; i < Constant::GameRow; ++i)
	{
		for (int j = 0; j < Constant::GameCol; ++j)
		{
			
			const float x1 = Constant::GamePosLX(i, j);
			const float y1 = Constant::GamePosLY(i, j);
			const float x2 = Constant::GamePosRX(i, j);
			const float y2 = Constant::GamePosRY(i, j);

			glRectf(x1, y1, x2, y2);
		}
	}


	SelectFont(Constant::ScoreSize, ANSI_CHARSET, Constant::TextFont);
	glColor3fv(Constant::TextColor);
	glRasterPos2f(Constant::ScoreX, Constant::ScoreY);
	DrawText(Constant::Score);

	SelectFont(Constant::ScoreSize, ANSI_CHARSET, Constant::TextFont);
	glColor3fv(Constant::TextColor);
	glRasterPos2f(Constant::NextX, Constant::NextY);
	DrawText(Constant::Next);
}

void GameWindow::DisplayScore(const int num)
{
	char str[100];
	Num2String(num, str);
	SelectFont(Constant::NumSize, ANSI_CHARSET, Constant::TextFont);
	glColor3fv(Constant::TextColor);
	glRasterPos2f(Constant::NumX, Constant::NumY);
	DrawText(str);
}

void GameWindow::DisplayAction(const std::vector<Block> &ths)
{
	std::vector<Block>::const_iterator it;
	for (it = ths.begin(); it != ths.end(); ++it)
	{
		glColor3fv(Constant::GameColor[it->getNum()]);
		const float x1 = Constant::GamePosLX(it->getPosi(), it->getPosj());
		const float y1 = Constant::GamePosLY(it->getPosi(), it->getPosj());
		const float x2 = Constant::GamePosRX(it->getPosi(), it->getPosj());
		const float y2 = Constant::GamePosRY(it->getPosi(), it->getPosj());
		glRectf(x1, y1, x2, y2);
		DrawNum(x1, y1, x2, y2,it->getNum());
	}

	DisplayNext(game.GetNextBlock());

	if (game.IsState(Constant::GamePause))
	{
		SelectFont(Constant::StateSize, ANSI_CHARSET, Constant::TextFont);
		glColor3fv(Constant::TextColor);
		glRasterPos2f(Constant::StateX, Constant::StateY);
		DrawText(Constant::Pause);
	}

	if (game.IsState(Constant::GameFinished))
	{
		SelectFont(Constant::StateSize, ANSI_CHARSET, Constant::TextFont);
		glColor3fv(Constant::TextColor);
		glRasterPos2f(Constant::StateX, Constant::StateY);
		DrawText(Constant::Finish);
	}
}

void GameWindow::DisplayNext(const std::vector<Block> &ths)
{
	std::vector<Block>::const_iterator it;
	for (it = ths.begin(); it != ths.end(); ++it)
	{
		glColor3fv(Constant::GameColor[it->getNum()]);
		const float x1 = Constant::NextPosLX(it->getPosi(), it->getPosj());
		const float y1 = Constant::NextPosLY(it->getPosi(), it->getPosj());
		const float x2 = Constant::NextPosRX(it->getPosi(), it->getPosj());
		const float y2 = Constant::NextPosRY(it->getPosi(), it->getPosj());

		//std::cout<<y1<<' '<<y2<<"\n";

		glRectf(x1, y1, x2, y2);
		DrawNum(x1, y1, x2, y2, it->getNum());
	}

}

void GameWindow::DrawNum(float x1, float y1, float x2,float y2, int num)
{
	float posx = ( x1 + x2 ) / 2;
	float posy = ( y1 + y2 ) / 2;


	char str[100];
	Num2String(1<<num, str);

	posx = posx - Constant::BlockNumPos;
	posy = posy - Constant::BlockNumPos;
	if(1<<num > 10)	  posx -= Constant::BlockNumPos / 2;
	if(1<<num > 100)  posx -= Constant::BlockNumPos;
	if(1<<num > 1000) posx -= Constant::BlockNumPos; 


	SelectFont(Constant::BlockNumSize, ANSI_CHARSET, Constant::TextFont);
	glColor3f(1.0f, 1.0f, 1.0f);
	glRasterPos2f(posx, posy);

	DrawText(str);
}

void GameWindow::SelectFont(int size, int charset, const char* face)
{
	HFONT hFont = CreateFontA(size, 0, 0, 0, FW_MEDIUM, 0, 0, 0,  
		charset, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,  
		DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, face);  
	HFONT hOldFont = (HFONT)SelectObject(wglGetCurrentDC(), hFont);  
	DeleteObject(hOldFont);  
}

void GameWindow::Num2String(int num, char *str)
{
	
	if (num == 0)
	{
		str[0] = '0';
		str[1] = '\0';
		return;
	}
	char tmp[100];
	int len = 0;

	while (num != 0)
	{
		tmp[len++] = num % 10 + '0';
		num /= 10;
	}
	for(int i = len - 1; i >= 0; --i)
		str[len - i - 1] = tmp[i];
	str[len] = '\0';
}

void GameWindow::DrawText(const char *str)
{
	static int isFirstCall = 1;  
	static GLuint lists;  

	if (isFirstCall) 
	{  
		isFirstCall = 0;  
		lists = glGenLists(Constant::MAX_CHAR); 
		wglUseFontBitmaps(wglGetCurrentDC(), 0, Constant::MAX_CHAR, lists);  
	}  
	for (; *str != '\0'; ++str) 
	{  
		glCallList(lists + *str);
	}
}

void GameWindow::Update()
{
	glutPostRedisplay();
}

