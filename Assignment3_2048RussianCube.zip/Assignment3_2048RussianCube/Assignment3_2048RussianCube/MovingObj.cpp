

#include "MovingObj.h"

MovingObj::MovingObj(){}
MovingObj::~MovingObj(){}

MovingObj::MovingObj(const MovingObj &rhs)
{
	p_mPosi		=	rhs.p_mPosi;
	p_mPosj		=	rhs.p_mPosj;
	p_mSize		=	rhs.p_mSize;
	p_mChoice	=	rhs.p_mChoice;
	for (int i = 0; i < 4; ++i)
	{
		p_mblocks[i] = rhs.p_mblocks[i];
	}
}

MovingObj& MovingObj::operator=(const MovingObj &rhs)
{
	p_mPosi		=	rhs.p_mPosi;
	p_mPosj		=	rhs.p_mPosj;
	p_mSize		=	rhs.p_mSize;
	p_mChoice	=	rhs.p_mChoice;
	for (int i = 0; i < 4; ++i)
	{
		p_mblocks[i] = rhs.p_mblocks[i];
	}

	return *this;
}

void MovingObj::Init(const std::vector<Block> &rhs, int choice)
{
	std::vector<Block>::const_iterator it;
	int itr = 0;
	for (it = rhs.begin(); it != rhs.end(); ++it)
	{
		p_mblocks[itr++] = *it;
	}
	p_mChoice = choice;
	p_mPosi = 0;
	p_mPosj = 2;

	if (choice == 0)
	{
		p_mSize = 2;	return;
	}
	if (choice == 1)
	{
		p_mSize = 4;	return;
	}
	p_mSize = 3;		return;
}

bool MovingObj::mvH(bool p)
{
	if(p)	p_mPosj += 1;
	else	p_mPosj -= 1;

	for (int i = 0; i < 4; ++i)
	{
		int ni = p_mblocks[i].getPosi() + p_mPosi;
		int nj = p_mblocks[i].getPosj() + p_mPosj;
		if (ni < 0 || ni >= Constant::GameRow || nj < 0 || nj >= Constant::GameCol)
		{
			return false;
		}
	}
	return true;
}

bool MovingObj::mvV(bool p /* = false */)
{
	p_mPosi += 1;
	if(p) p_mPosi += 1;
	for (int i = 0; i < 4; ++i)
	{
		int ni = p_mblocks[i].getPosi() + p_mPosi;
		int nj = p_mblocks[i].getPosj() + p_mPosj;
		if (ni < 0 || ni >= Constant::GameRow || nj < 0 || nj >= Constant::GameCol)
		{
			return false;
		}
	}
	return true;
}

bool MovingObj::rtC(bool p /* = true */)
{
	for (int i = 0; i < 4; ++i)
	{
		int ni = p_mblocks[i].getPosi();
		int nj = p_mblocks[i].getPosj();
		int nm = p_mblocks[i].getNum();
		int tmp;
		tmp = ni;
		ni = nj;
		nj = p_mSize - tmp - 1;
		p_mblocks[i].reSet(ni, nj, nm);
	}

	for (int i = 0; i < 4; ++i)
	{
		int ni = p_mblocks[i].getPosi() + p_mPosi;
		int nj = p_mblocks[i].getPosj() + p_mPosj;
		if (ni < 0 || ni >= Constant::GameRow || nj < 0 || nj >= Constant::GameCol)
		{
			return 0;
		}
	}
	return 1;
}

std::vector<Block> MovingObj::getStates() const
{
	std::vector<Block> tmp(p_mblocks, p_mblocks + 4);
	std::vector<Block>::iterator it;
	for (it = tmp.begin(); it != tmp.end(); ++it)
	{
		int ni = it->getPosi() + p_mPosi;
		int nj = it->getPosj() + p_mPosj;
		int nm = it->getNum();
		it->reSet(ni, nj, nm);
	}
	return tmp;
}

