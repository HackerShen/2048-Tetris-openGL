
#ifndef NextObj_h
#define NextObj_h

#include <vector>
#include <cstdlib>
#include <ctime>
#include "Block.h"


class NextObj
{
public:
	NextObj();
	~NextObj();

	// get info
	//TODO get blocks
	std::vector<Block> getBlocks() const ;

	//TODO get size
	int getChoice() const;

	// modify
	//TODO generate next obj use rand() function
	void initNext();

private:

	//TODO init next blocks
	void NextBlocks(int choice);

	//TOOD init next size
	void NextChoice(int choice);

	int		p_mChoice;					// 0 ~ 6
	Block	p_mblocks[4];
	static bool isFirstCalled;
};


#endif