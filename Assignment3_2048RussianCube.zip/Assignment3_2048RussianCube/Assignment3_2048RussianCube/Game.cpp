
#include "Game.h"


Game::Game(int)
{
	GameInit();
}

Game::~Game(){}

void Game::MovingHorizontal(bool direction)
{
	if (!IsState(Constant::GameReady))
	{
		return ;
	}

	MovingObj cpyMvObj(p_movingObj);
	RemainObj cpyRmObj(p_remainObj);

	if (!cpyMvObj.mvH(direction))
	{
		return ;
	}
	
	cpyRmObj.addBlocks(cpyMvObj.getStates());

	if (!cpyRmObj.isLegal())
	{
		return ;
	}

	p_movingObj = cpyMvObj;
}

void Game::MovingRotate(bool direction /* = true */)
{
	if (!IsState(Constant::GameReady))
	{
		return ;
	}

	MovingObj cpyMvObj(p_movingObj);
	RemainObj cpyRmObj(p_remainObj);

	if (!cpyMvObj.rtC(direction))
	{
		return ;
	}

	cpyRmObj.addBlocks(cpyMvObj.getStates());

	if (!cpyRmObj.isLegal())
	{
		return ;
	}

	p_movingObj = cpyMvObj;
}

void Game::MovingVertical(bool direction /* = false */)
{
	if (!IsState(Constant::GameReady))
	{
		return ;
	}

	p_mScore += p_remainObj.clearBlocks();

	MovingObj cpyMvObj(p_movingObj);
	RemainObj cpyRmObj(p_remainObj);

	if (!cpyMvObj.mvV(direction))
	{
		p_remainObj.addBlocks(p_movingObj.getStates());
		p_movingObj.Init(p_nextObj.getBlocks(), p_nextObj.getChoice());
		p_nextObj.initNext();
		p_mScore += p_remainObj.clearBlocks();
		
		isFinished();
		return ;
	}

	cpyRmObj.addBlocks(cpyMvObj.getStates());

	if (!cpyRmObj.isLegal())
	{
		p_remainObj.addBlocks(p_movingObj.getStates());
		p_movingObj.Init(p_nextObj.getBlocks(), p_nextObj.getChoice());
		p_nextObj.initNext();
		p_mScore += p_remainObj.clearBlocks();

		isFinished();
		return ;
	}

	p_movingObj = cpyMvObj;
}

void Game::GameInit()
{
	p_remainObj.Init();
	p_nextObj.initNext();
	p_movingObj.Init(p_nextObj.getBlocks(), p_nextObj.getChoice());
	p_nextObj.initNext();

	p_mScore = 0;
	InitStates();
}

void Game::GameStop()
{
	SetState(Constant::GamePause);
}

void Game::GameContinue()
{
	if (IsState(Constant::GamePause))
	{
		SetState(Constant::GameReady);
	}
}

std::vector<Block> Game::GetBlocksState() const
{
	std::vector<Block>rmBlocks(p_remainObj.getStates());
	std::vector<Block>mvBlocks(p_movingObj.getStates());
	std::vector<Block>rtBlocks;
	std::vector<Block>::iterator it;
	for (it = rmBlocks.begin(); it != rmBlocks.end(); ++it)
	{
		rtBlocks.push_back(*it);
	}

	for (it = mvBlocks.begin(); it != mvBlocks.end(); ++it)
	{
		rtBlocks.push_back(*it);
	}

	return rtBlocks;
}

std::vector<Block> Game::GetNextBlock() const
{
	std::vector<Block>rtBlocks(p_nextObj.getBlocks());
	return rtBlocks;
}

int Game::GetScores() const
{
	return p_mScore;
}

bool Game::IsState(int state) const
{
	return p_mState == state;
}

void Game::InitStates()
{
	p_mState = Constant::GameReady;
}

void  Game::SetState(int state)
{
	p_mState = state;
}

bool Game::isFinished()
{
	RemainObj cpyRmObj(p_remainObj);
	cpyRmObj.addBlocks(p_movingObj.getStates());

	if(! cpyRmObj.isLegal())
	{
		SetState(Constant::GameFinished);
		return true;
	}

	return false;
}