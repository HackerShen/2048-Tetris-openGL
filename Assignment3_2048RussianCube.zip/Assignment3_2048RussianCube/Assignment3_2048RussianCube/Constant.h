//TODO constants

#ifndef Constant_h
#define Constant_h

class Constant
{
public:

	// text
	//TODO Text
	static const char *Title;
	static const char *Score;
	static const char *Next;
	static const char *Pause;
	static const char *Finish;

	static const float TextColor[3];
	//"Comic Sans MS"
	static const char* TextFont;

	//TODO score (text)
	static const int ScoreSize		= 24;
	static const float ScoreX;
	static const float ScoreY;

	//TODO score (numbers)
	static const int NumSize		= 24;
	static const float NumX;
	static const float NumY;

	//TODO next 
	static const int NextSize		= 24;
	static const float NextX;
	static const float NextY;

	//TODO stop or finish
	static const int StateSize		= 24;
	static const float StateX;
	static const float StateY;

	static const int MAX_CHAR		= 128;

	//TODO number on blocks
	static const int BlockNumSize	= 6;
	static const float BlockNumPos;



	//TODO delay time
	static const int DelayTime		= 650;
	static const int WindowWidth	= 650;
	static const int WindowHeight	= 650;
	static const int WindowPosX		= 200;
	static const int WindowPosY		= 50;

	//TODO grid
	static const int GameRow		= 16;
	static const int GameCol		= 8;

	//TODO game
	static const float GameColor[11][3];
	static const float GamePosLX(int i, int j);
	static const float GamePosRX(int i, int j);
	static const float NextPosLX(int i, int j);
	static const float NextPosRX(int i, int j);
	static const float GamePosLY(int i, int j);
	static const float GamePosRY(int i, int j);
	static const float NextPosLY(int i, int j);
	static const float NextPosRY(int i, int j);

	//TODO states
	static const int GameReady		= 0;
	static const int GamePause		= 1;
	static const int GameFinished	= 2;


	static const float edgeWidth;
	static const float lineWidth;
	static const float stX;
	static const float stY;


	static float gamePosL[GameRow][GameCol][2];
	static float gamePosR[GameRow][GameCol][2];
	static float nextPosL[4][4][2];
	static float nextPosR[4][4][2];
};


#endif