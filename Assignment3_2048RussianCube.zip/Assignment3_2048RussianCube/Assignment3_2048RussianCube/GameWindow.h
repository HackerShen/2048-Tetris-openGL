
//TODO UI and Animation
#ifndef GameWindow_h
#define GameWindow_h


#include <iostream>
#include <vector>

#include <windows.h>
#include <GL/glut.h>


#include "Game.h"

class GameWindow
{
public:
	static void Init(int argc, char *argv[]);
	static void Start();

private:
	//TODO global game obj
	static Game game;

	//TODO MAIN reshape
	static void ReshapeFunc(GLsizei w, GLsizei h);

	//TODO MAIN display
	static void DisplayFunc();

	//TODO MAIN keyboard control
	static void KeyboardFunc(unsigned char key, int x,int y);

	//TODO MAIN ths timer function
	static void TimeFunc(int value);

	//TODO display background
	static void DisplayBackground();

	//TODO display score
	static void DisplayScore(const int num);

	//TODO display blocks
	static void DisplayAction(const std::vector<Block> &ths);
	
	//TODO display next blocks
	static void DisplayNext(const std::vector<Block> &ths);

	//TODO draw number on blocks
	static void DrawNum(float x1, float y1, float x2, float y2, int num);

	//TODO select font
	static void SelectFont(int size, int charset, const char *face);

	//TODO change num to string
	static void Num2String(int num, char *str);

	//TODO draw text
	static void DrawText(const char *str);

	//TODO update
	static void Update();
};


#endif