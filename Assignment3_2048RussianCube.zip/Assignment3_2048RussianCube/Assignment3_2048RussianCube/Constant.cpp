
#include "Constant.h"


const char* Constant::Title		= "2048 & Russian Cube by syj";
const char* Constant::Score		= "Your Score:";
const char* Constant::Next		= "Next Cube:";
const char* Constant::Pause		= "Paused (press \"C\" to continue)";
const char* Constant::Finish	= "Finished (press \"R\" to continue)";


const float Constant::TextColor[3] =
{
	1.0f, 0.1f, 0.0f,
};

const char* Constant::TextFont	= "Comic Sans MS";

const float Constant::ScoreX	= 0.4f;
const float Constant::ScoreY	= 0.8f;

const float Constant::NumX		= 0.4f;
const float Constant::NumY		= 0.7f;

const float Constant::NextX		= 0.4f;
const float Constant::NextY		= 0.0f;

const float Constant::StateX	= -0.5f;
const float Constant::StateY	= 0.4f;

const float Constant::GameColor[11][3] =
{
	(float)0xd9 / (float)0xff , (float)0xd9 / (float)0xff, (float)0xd9 / (float)0xff ,
	(float)0xff / (float)0xff , (float)0xe0 / (float)0xff, (float)0x00 / (float)0xff ,
	(float)0xff / (float)0xff , (float)0xb3 / (float)0xff, (float)0x00 / (float)0xff ,
	(float)0xff / (float)0xff , (float)0x92 / (float)0xff, (float)0x00 / (float)0xff ,
	(float)0xff / (float)0xff , (float)0x81 / (float)0xff, (float)0x00 / (float)0xff ,
	(float)0xff / (float)0xff , (float)0x64 / (float)0xff, (float)0x00 / (float)0xff ,
	(float)0xff / (float)0xff , (float)0x52 / (float)0xff, (float)0x00 / (float)0xff ,
	(float)0xff / (float)0xff , (float)0x42 / (float)0xff, (float)0x00 / (float)0xff ,
	(float)0xff / (float)0xff , (float)0x30 / (float)0xff, (float)0x00 / (float)0xff ,
	(float)0xff / (float)0xff , (float)0x1d / (float)0xff, (float)0x00 / (float)0xff ,
	(float)0xff / (float)0xff , (float)0x09 / (float)0xff, (float)0x00 / (float)0xff ,
};


const float Constant::stX			= -0.850f;
const float Constant::stY			= 0.940f;
const float Constant::edgeWidth		= 0.120f;
const float Constant::lineWidth		= 0.005f;
const float Constant::BlockNumPos	= 0.020f; 


const float Constant::GamePosLX(int i, int j)
{
/*	gamePosL[i][j][0]	=	stX + j * edgeWidth;*/
	
	return stX + j * edgeWidth + lineWidth;
}

const float Constant::GamePosLY(int i, int j)
{
/*	gamePosL[i][j][1]	=	stY - (i + 1) * edgeWidth;	*/
	return stY - (i + 1) * edgeWidth + lineWidth;	
}

const float Constant::GamePosRX(int i, int j)
{
/*	gamePosR[i][j][0]	=	stX + (j + 1) * edgeWidth;*/
	return stX + (j + 1) * edgeWidth - lineWidth;
}

const float Constant::GamePosRY(int i, int j)
{
/*	gamePosR[i][j][1]	=	stY - i * edgeWidth;*/
	return stY - i * edgeWidth - lineWidth;
}

const float Constant::NextPosLX(int i, int j)
{
/*	nextPosL[i][j][0]	=	NextX + j * edgeWidth;*/
	return NextX + j * edgeWidth + lineWidth;
}

const float Constant::NextPosLY(int i, int j)
{
/*	nextPosL[i][j][1]	=	NextY - (i + 1) * edgeWidth;*/
	return NextY - (i + 2) * edgeWidth + lineWidth;
}

const float Constant::NextPosRX(int i, int j)
{
/*	nextPosR[i][j][0]	=	NextX + (j + 1) * edgeWidth;*/

	return NextX + (j + 1) * edgeWidth - lineWidth;
}


const float Constant::NextPosRY(int i, int j)
{
	/*nextPosR[i][j][1]	=	NextY - (i + 2) * edgeWidth;*/
	return NextY - (i + 1) * edgeWidth - lineWidth;
}


