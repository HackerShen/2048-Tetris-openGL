
#ifndef RemainObj_h
#define RemainObj_h
#include <iostream>

#include <vector>
#include <queue>
#include "Constant.h"
#include "Block.h"

class RemainObj
{
public:
	RemainObj();
	RemainObj(const RemainObj &rhs);
	~RemainObj();

	// modify
	//TODO add blocks
	void addBlocks(const std::vector<Block> &ths);

	//TODO init
	void Init();

	//TODO 2048 clear return scores
	int clearBlocks();

	// get info
	//TODD get states
	std::vector<Block> getStates() const;
	
	//TODO whether it is legal
	bool isLegal();

private:
	

	//TODO set map 0
	void cleanUp();

	//TODO clear
	int BFS(int i, int j, bool vis[Constant::GameRow][Constant::GameCol]);

	//TODO generate states;
	void generateStates();

	std::vector<Block> p_mBlockWarehouse;
	
	//TODO constructor ans destructor
	int p_mGameMap[Constant::GameRow][Constant::GameCol];

	//TODO set gravity
	void setGravity(int i, int j, bool vis[Constant::GameRow][Constant::GameCol]);
};

#endif

// 	//TODO generate 2D state of the game
// 	void make2D();


// 	//TODO whether it is finished
// 	bool isFinished() const;
// 
// 	//TODO whether should next come
// 	bool isNextcalled() const;


// 	//TODO =
// 	RemainObj& operator=(const RemainObj &rhs);