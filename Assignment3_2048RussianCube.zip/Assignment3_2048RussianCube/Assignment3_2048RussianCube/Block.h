
//TODO basic class
#ifndef Block_h
#define Block_h

class Block
{
public:
	Block(int posi = 0, int posj = 0, int num = 0);
	Block(const Block &rhs);
	~Block();

	// Modify
	//TODO  =
	Block& operator=(const Block &rhs);

	//TODO reset
	void reSet(int posi = 0, int posj = 0, int num = 0);

	// Get information
	//TODO get number
	int getNum() const;

	//TODO get position
	const int* getPos() const;
	int getPosi() const;
	int getPosj() const;

private:
	int		p_mPosi, p_mPosj;
	int		p_mPos[2];
	int		p_mNum;
};


#endif



// 	//TODO  move horizontal  0 left 1 right
// 	void moveH(bool p);
// 
// 	//TODO move vertical  0 down1 1 down2 
// 	void moveV(bool p);
