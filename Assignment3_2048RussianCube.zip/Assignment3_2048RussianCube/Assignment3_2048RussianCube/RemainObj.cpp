
#include "RemainObj.h"

RemainObj::RemainObj()
{
	Init();
}
RemainObj::~RemainObj(){}

RemainObj::RemainObj(const RemainObj &rhs):
	p_mBlockWarehouse(rhs.p_mBlockWarehouse)
{
	for (int i = 0; i < Constant::GameRow; i++)
	{
		for (int j = 0; j < Constant::GameCol; j++)
		{
			p_mGameMap[i][j] = rhs.p_mGameMap[i][j];
		}
	}
}

void RemainObj::addBlocks(const std::vector<Block> &ths)
{
	std::vector<Block>::const_iterator it;
	for (it = ths.begin(); it != ths.end(); ++it)
	{
		p_mBlockWarehouse.push_back(*it);
	}
}

void RemainObj::Init()
{
	p_mBlockWarehouse.clear();
	cleanUp();
}

std::vector<Block> RemainObj::getStates() const
{
	return p_mBlockWarehouse;
}

int RemainObj::clearBlocks()
{
	int score = 0;
	if(! isLegal()) return 0;
	bool vis[Constant::GameRow][Constant::GameCol];
	for (int i = 0; i < Constant::GameRow; ++i)
	{
		for (int j = 0 ; j < Constant::GameCol; ++j)
		{
			vis[i][j] = 1;
		}
	}

	for (int i = Constant::GameRow - 1; i >= 0; --i)
	{
		for (int j = 0; j < Constant::GameCol; ++j)
		{
			score += BFS(i, j, vis);
		}
	}

	for (int j = 0; j < Constant::GameCol; ++j)
	{
		int i = Constant::GameRow - 1;
		if(vis[i][j] && p_mGameMap[i][j] != 0)
		{
			setGravity(i, j, vis);
		}
	}

// 	for (int i = 0; i < Constant::GameRow - 1; ++i)
// 	{
// 		for (int j = 0 ; j < Constant::GameCol; ++j)
// 		{
// 			
// 			if (p_mGameMap[i + 1][j] == 0 && vis[i][j])
// 			{
// 				vis[i + 1][j] = 1;
// 			}
// 		}
// 	}

	for(int j = 0; j < Constant::GameCol; ++j)
	{
		for(int i = Constant::GameRow - 2; i >= 0; --i)
		{
			if(p_mGameMap[i][j] != 0 && vis[i][j])
			{
				int downRow = i + 1;
				int nowRow = i;
				

				while(downRow < Constant::GameRow && p_mGameMap[downRow][j] == 0 && vis[downRow][j])
				{
					p_mGameMap[downRow][j] = p_mGameMap[nowRow][j];
					p_mGameMap[nowRow][j] = 0;
					nowRow = downRow;
					++downRow; 
				}
			}
		}
	}

	generateStates();
	return score;
}

bool RemainObj::isLegal()
{
	cleanUp();
	std::vector<Block>::const_iterator it;
	for (it = p_mBlockWarehouse.begin(); it != p_mBlockWarehouse.end(); ++it)
	{
		int i = it->getPosi();
		int j = it->getPosj();
		int num = it->getNum();
		if (p_mGameMap[i][j] != 0)
		{
			return false;
		}
		p_mGameMap[i][j] = num;
	}
	return true ;
}

void RemainObj::cleanUp()
{
	for (int i = 0; i < Constant::GameRow; i++)
	{
		for (int j = 0; j < Constant::GameCol; j++)
		{
			p_mGameMap[i][j] = 0;
		}
	}
}

int RemainObj::BFS(int i, int j, bool vis[Constant::GameRow][Constant::GameCol])
{
	if(p_mGameMap[i][j] == 0) return 0;

	int score	= 0;
	int num		= 0;
	int mvi[] = {1, -1, 0, 0};
	int mvj[] = {0, 0, 1, -1};
	std::queue<int> qi;
	std::queue<int> qj;
	qi.push(i);
	qj.push(j);

	while (!qi.empty())
	{
		
		int ui = qi.front();
		int uj = qj.front();
		qi.pop();
		qj.pop();

		int vi;
		int vj;
		for (int k = 0; k < 4; ++k)
		{
			vi = ui + mvi[k];
			vj = uj + mvj[k];

			if(vi == i && vj == j) continue;
			if(vi < 0 || vi >= Constant::GameRow || vj < 0 || vj >= Constant::GameCol) continue;
			if(p_mGameMap[vi][vj] != p_mGameMap[i][j]) continue;

			p_mGameMap[vi][vj] = 0;
			qi.push(vi);
			qj.push(vj);
// 			vis[vi][vj] = 1;
// 			vis[i][j] = 1;
			++num;
		}
	}
	score = (1<<p_mGameMap[i][j]) * num;
	p_mGameMap[i][j] = ( p_mGameMap[i][j] + num ) % 11;
	return score;
}

void RemainObj::generateStates()
{
	p_mBlockWarehouse.clear();
	for (int i = 0; i < Constant::GameRow; ++i)
	{
		for (int j = 0; j < Constant::GameCol; ++j)
		{
			if (p_mGameMap[i][j] != 0)
			{
				p_mBlockWarehouse.push_back(Block(i, j, p_mGameMap[i][j]));
			}
		}
	}
}


void RemainObj::setGravity(int i, int j, bool vis[Constant::GameRow][Constant::GameCol])
{
	int mvi[] = {1, -1, 0, 0};
	int mvj[] = {0, 0, 1, -1};
	std::queue<int> qi;
	std::queue<int> qj;
	qi.push(i);
	qj.push(j);
	vis[i][j] = 0;

	while (!qi.empty())
	{

		int ui = qi.front();
		int uj = qj.front();
		qi.pop();
		qj.pop();

		int vi;
		int vj;
		for (int k = 0; k < 4; ++k)
		{
			vi = ui + mvi[k];
			vj = uj + mvj[k];

			if(vis[vi][vj] == 0) continue;
			if(vi < 0 || vi >= Constant::GameRow || vj < 0 || vj >= Constant::GameCol) continue;
			if(p_mGameMap[vi][vj] == 0) continue;

			qi.push(vi);
			qj.push(vj);
			vis[vi][vj] = 0;
		}
	}
}