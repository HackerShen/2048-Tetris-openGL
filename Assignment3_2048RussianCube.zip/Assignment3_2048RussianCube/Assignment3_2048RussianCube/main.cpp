

#include <ctime>
#include <cstdlib>
#include "GameWindow.h"


int main(int argc, char *argv[])
{

	GameWindow::Init(argc, argv);

	GameWindow::Start();

	return 0;
}