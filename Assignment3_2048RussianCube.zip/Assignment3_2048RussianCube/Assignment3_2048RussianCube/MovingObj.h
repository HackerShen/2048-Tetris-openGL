#ifndef MovingObj_h
#define MovingObj_h

#include <vector>
#include "Constant.h"

#include "Block.h"


class MovingObj
{
public:
	MovingObj();
	MovingObj(const MovingObj &rhs);
	~MovingObj();
	
	// modify
	//TODO init
	void Init(const std::vector<Block> &rhs, int choice);

	//TODO =
	MovingObj& operator=(const MovingObj &rhs);

	//TODO moving horizontally if meet edge return false
	// 0 for left 1 for right
	bool mvH(bool p);

	//TODO moving vertically if meet edge return false
	// 0 for down 1 1 for down 2
	bool mvV(bool p = false);

	//TODO rotate if meet edge return false
	bool rtC(bool p = true);


	// get info
	//TODO get states
	std::vector<Block> getStates() const ;

private:

	int		p_mPosi, p_mPosj;
	int		p_mChoice;
	int		p_mSize;
	Block	p_mblocks[4];
};

#endif


	//MovingObj(const std::vector<Block> &rhs, int size);


// 	//TODO rotate clockwise (positive)
// 	bool rtPC();
// 	//TODO rotate counter clockwise (negative)
// 	bool rtNC();
